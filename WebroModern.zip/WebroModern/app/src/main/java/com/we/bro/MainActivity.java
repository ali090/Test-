package com.we.bro;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebView.HitTestResult;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private LinearLayout homeLayout;
    private LinearLayout browserLayout;
    private ImageView backgroundImage;
    private EditText searchBar;
    private Button btnChangeBg;
    private FrameLayout webviewContainer;
    private EditText urlBar;
    private ProgressBar progressBar;
    private Button btnForward, btnRefresh, btnMenu, btnTabs, btnHome;
    private boolean isDarkMode = false;
    private boolean isAdBlockerEnabled = false;
    private boolean isIncognitoMode = false; // وضع التصفح الخاص
    private List<WebView> tabs = new ArrayList<>();
    private List<String> history = new ArrayList<>();
    private List<Long> downloadIds = new ArrayList<>();
    private int currentTabIndex = -1;

    // متغيرات وضع الشاشة الكاملة
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private static final String PREFS_NAME = "WebroPrefs";
    private static final String KEY_DARK_MODE = "dark_mode";
    private static final String KEY_HISTORY = "history";
    private static final String KEY_CURRENT_TAB = "current_tab";
    private static final String KEY_TAB_URLS = "tab_urls";
    private static final String KEY_BG_IMAGE_PATH = "bg_image_path";
    private static final String KEY_INCOGNITO_MODE = "incognito_mode"; // لحفظ حالة الوضع الخاص

    private static final int REQUEST_READ_STORAGE = 101;
    private static final int PICK_IMAGE_REQUEST = 102;

    // تعريف مستقبل التنزيلات
    private BroadcastReceiver downloadCompleteReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            if (downloadIds.contains(id)) {
                Toast.makeText(MainActivity.this, "تم تنزيل الملف", Toast.LENGTH_SHORT).show();
                downloadIds.remove(id);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registerReceiver(downloadCompleteReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

        homeLayout = findViewById(R.id.home_layout);
        browserLayout = findViewById(R.id.browser_layout);
        backgroundImage = findViewById(R.id.background_image);
        searchBar = findViewById(R.id.search_bar);
        btnChangeBg = findViewById(R.id.btn_change_bg);

        webviewContainer = (FrameLayout) browserLayout.findViewById(R.id.webview_container);
        urlBar = (EditText) browserLayout.findViewById(R.id.url_bar);
        progressBar = (ProgressBar) browserLayout.findViewById(R.id.progress_bar);
        btnForward = (Button) browserLayout.findViewById(R.id.btn_forward);
        btnRefresh = (Button) browserLayout.findViewById(R.id.btn_refresh);
        btnMenu = (Button) browserLayout.findViewById(R.id.btn_menu);
        btnTabs = (Button) browserLayout.findViewById(R.id.btn_tabs);
        btnHome = (Button) browserLayout.findViewById(R.id.btn_home);

        restoreState(savedInstanceState);

        searchBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
				@Override
				public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
					if (actionId == EditorInfo.IME_ACTION_SEARCH) {
						performSearch(searchBar.getText().toString());
						return true;
					}
					return false;
				}
			});

        btnChangeBg.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					checkStoragePermission();
				}
			});

        btnForward.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					goForward();
				}
			});

        btnRefresh.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					getCurrentWebView().reload();
				}
			});

        btnMenu.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showMenu();
				}
			});

        btnTabs.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showTabsDialog();
				}
			});

        btnHome.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					homeLayout.setVisibility(View.VISIBLE);
					browserLayout.setVisibility(View.GONE);
				}
			});

        urlBar.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (getCurrentWebView() != null) {
						urlBar.setText(getCurrentWebView().getUrl());
						urlBar.selectAll();
					}
				}
			});

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
				@Override
				public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
					if (actionId == EditorInfo.IME_ACTION_GO) {
						loadUrl(urlBar.getText().toString());
						return true;
					}
					return false;
				}
			});

        // تحديث الواجهة حسب وضع التصفح الخاص
        updateIncognitoUI();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // منع إعادة إنشاء النشاط عند تدوير الجهاز
    }

    private void performSearch(String query) {
        if (query.trim().isEmpty()) return;

        homeLayout.setVisibility(View.GONE);
        browserLayout.setVisibility(View.VISIBLE);

        if (tabs.isEmpty()) {
            newTab("", true);
        }

        String url;
        if (query.contains(".") && !query.contains(" ")) {
            url = query.startsWith("http") ? query : "https://" + query;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(query);
        }

        loadUrlInCurrentTab(url);
    }

    private void checkStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
				!= android.content.pm.PackageManager.PERMISSION_GRANTED) {

                requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},
								   REQUEST_READ_STORAGE);
            } else {
                openImagePicker();
            }
        } else {
            openImagePicker();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_READ_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                openImagePicker();
            } else {
                Toast.makeText(this, "يجب منح الإذن لتغيير الخلفية", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            try {
                String imagePath = saveImageToInternalStorage(selectedImageUri);
                applyCustomBackground(imagePath);
                saveBackgroundPath(imagePath);
            } catch (Exception e) {
                Toast.makeText(this, "خطأ في تحميل الصورة", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }

    private String saveImageToInternalStorage(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

        File directory = getApplicationContext().getDir("backgrounds", Context.MODE_PRIVATE);
        File file = new File(directory, "custom_bg.jpg");

        FileOutputStream fos = new FileOutputStream(file);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
        fos.close();
        inputStream.close();

        return file.getAbsolutePath();
    }

    private void applyCustomBackground(String imagePath) {
        Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
        if (bitmap != null) {
            backgroundImage.setImageBitmap(bitmap);
            Toast.makeText(this, "تم تغيير الخلفية بنجاح", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveBackgroundPath(String imagePath) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_BG_IMAGE_PATH, imagePath);
        editor.apply();
    }

    private void restoreCustomBackground() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String imagePath = prefs.getString(KEY_BG_IMAGE_PATH, null);

        if (imagePath != null) {
            File file = new File(imagePath);
            if (file.exists()) {
                applyCustomBackground(imagePath);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (browserLayout.getVisibility() == View.VISIBLE) {
            WebView current = getCurrentWebView();
            if (current != null && current.canGoBack()) {
                current.goBack();
            } else {
                browserLayout.setVisibility(View.GONE);
                homeLayout.setVisibility(View.VISIBLE);
            }
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // حفظ حالة كل WebView
        for (int i = 0; i < tabs.size(); i++) {
            WebView webView = tabs.get(i);
            Bundle webViewState = new Bundle();
            webView.saveState(webViewState);
            outState.putBundle("webViewState_" + i, webViewState);
        }

        saveState(outState);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveStateToPrefs();
        unregisterReceiver(downloadCompleteReceiver);
    }

    private void restoreState(Bundle savedInstanceState) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        isDarkMode = prefs.getBoolean(KEY_DARK_MODE, false);
        isIncognitoMode = prefs.getBoolean(KEY_INCOGNITO_MODE, false); // استعادة وضع التصفح الخاص

        Set<String> historySet = prefs.getStringSet(KEY_HISTORY, null);
        if (historySet != null) {
            history = new ArrayList<>(historySet);
        }

        if (savedInstanceState != null) {
            // استعادة حالة WebView لكل تبويب
            int tabCount = 0;
            while (savedInstanceState.containsKey("webViewState_" + tabCount)) {
                Bundle webViewState = savedInstanceState.getBundle("webViewState_" + tabCount);
                WebView webView = createWebView();
                webView.restoreState(webViewState);
                tabs.add(webView);
                tabCount++;
            }

            currentTabIndex = savedInstanceState.getInt(KEY_CURRENT_TAB, 0);
            if (tabCount > 0) {
                switchToTab(currentTabIndex);
            }
        } else {
            String tabUrlsStr = prefs.getString(KEY_TAB_URLS, "");
            String[] tabUrls = tabUrlsStr.split(",");
            currentTabIndex = prefs.getInt(KEY_CURRENT_TAB, 0);

            if (tabUrls.length > 0 && !tabUrls[0].isEmpty()) {
                for (String url : tabUrls) {
                    if (!url.isEmpty()) {
                        newTab(url, false);
                    }
                }
                switchToTab(currentTabIndex);
            }
        }

        restoreCustomBackground();
        updateIncognitoUI(); // تحديث الواجهة حسب وضع التصفح الخاص

        if (tabs.isEmpty()) {
            homeLayout.setVisibility(View.VISIBLE);
            browserLayout.setVisibility(View.GONE);
        } else {
            homeLayout.setVisibility(View.GONE);
            browserLayout.setVisibility(View.VISIBLE);
        }
    }

    private void saveState(Bundle outState) {
        String[] tabUrls = new String[tabs.size()];
        for (int i = 0; i < tabs.size(); i++) {
            tabUrls[i] = tabs.get(i).getUrl();
        }
        outState.putStringArray(KEY_TAB_URLS, tabUrls);
        outState.putInt(KEY_CURRENT_TAB, currentTabIndex);
    }

    private void saveStateToPrefs() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putBoolean(KEY_DARK_MODE, isDarkMode);
        editor.putBoolean(KEY_INCOGNITO_MODE, isIncognitoMode); // حفظ وضع التصفح الخاص

        Set<String> historySet = new HashSet<>(history);
        editor.putStringSet(KEY_HISTORY, historySet);

        StringBuilder tabUrls = new StringBuilder();
        for (WebView tab : tabs) {
            String url = tab.getUrl();
            if (url != null && !url.isEmpty()) {
                tabUrls.append(url).append(",");
            }
        }
        if (tabUrls.length() > 0) {
            tabUrls.deleteCharAt(tabUrls.length() - 1);
        }
        editor.putString(KEY_TAB_URLS, tabUrls.toString());

        editor.putInt(KEY_CURRENT_TAB, currentTabIndex);

        editor.apply();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private WebView createWebView() {
        WebView webView = new WebView(this);
        setupWebView(webView);
        return webView;
    }

    private void setupWebView(WebView webView) {
        webView.setWebViewClient(new CustomWebViewClient());
        webView.setWebChromeClient(new CustomWebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);

        // إعدادات الخصوصية لوضع التصفح الخاص
        if (isIncognitoMode) {
            webView.getSettings().setSaveFormData(false);
            webView.getSettings().setSavePassword(false);
            webView.clearHistory();
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            webView.getSettings().setForceDark(isDarkMode ? 
											   WebSettings.FORCE_DARK_ON : WebSettings.FORCE_DARK_OFF);
        }

        webView.setDownloadListener(new DownloadListener() {
				@Override
				public void onDownloadStart(String url, String userAgent, 
											String contentDisposition, String mimeType, long contentLength) {
					startDownload(url, URLUtil.guessFileName(url, contentDisposition, mimeType));
				}
			});

        registerForContextMenu(webView);
    }

    private void startDownload(String url, String fileName) {
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setTitle(fileName);
        request.setDescription("جاري التنزيل...");
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        long downloadId = manager.enqueue(request);
        downloadIds.add(downloadId);

        Toast.makeText(this, "بدأ التنزيل: " + fileName, Toast.LENGTH_SHORT).show();
    }

    private void newTab(String url, boolean switchToIt) {
        WebView newWebView = createWebView();
        tabs.add(newWebView);

        if (switchToIt || currentTabIndex == -1) {
            switchToTab(tabs.size() - 1);
        }

        if (url != null && !url.isEmpty()) {
            loadUrlInCurrentTab(url);
        }
    }

    private void switchToTab(int index) {
        if (index < 0 || index >= tabs.size()) return;

        for (WebView tab : tabs) {
            if (tab.getParent() != null) {
                ((FrameLayout) tab.getParent()).removeView(tab);
            }
        }

        WebView currentWebView = tabs.get(index);
        if (currentWebView.getParent() == null) {
            webviewContainer.addView(currentWebView);
        }
        currentWebView.setVisibility(View.VISIBLE);

        currentTabIndex = index;
        updateUrlBar();
    }

    private void closeCurrentTab() {
        if (tabs.size() <= 1) {
            Toast.makeText(this, "لا يمكن إغلاق آخر تبويب", Toast.LENGTH_SHORT).show();
            return;
        }

        WebView currentWebView = getCurrentWebView();
        webviewContainer.removeView(currentWebView);
        tabs.remove(currentTabIndex);

        int newIndex = Math.max(0, currentTabIndex - 1);
        switchToTab(newIndex);
    }

    private void showTabsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("التبويبات المفتوحة (" + tabs.size() + ")");

        final String[] tabTitles = new String[tabs.size()];
        for (int i = 0; i < tabs.size(); i++) {
            WebView tab = tabs.get(i);
            String title = tab.getTitle();
            if (title == null || title.isEmpty()) {
                title = tab.getUrl();
            }
            if (title == null) title = "تبويب جديد";

            tabTitles[i] = (i == currentTabIndex ? "→ " : "") + title;
        }

        builder.setItems(tabTitles, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					switchToTab(which);
				}
			});

        builder.setNegativeButton("إغلاق", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});

        builder.setNeutralButton("تبويب جديد", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					newTab("https://www.google.com", true);
				}
			});

        builder.show();
    }

    private void loadUrl(String url) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "الرجاء إدخال رابط", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            if (url.startsWith("www.")) {
                url = "https://" + url;
            } else if (url.contains(".") && !url.contains(" ")) {
                url = "https://" + url;
            } else {
                url = "https://www.google.com/search?q=" + Uri.encode(url);
            }
        }

        loadUrlInCurrentTab(url);
    }

    private void loadUrlInCurrentTab(String url) {
        if (getCurrentWebView() != null) {
            getCurrentWebView().loadUrl(url);
        }
    }

    private void goForward() {
        if (getCurrentWebView() != null && getCurrentWebView().canGoForward()) {
            getCurrentWebView().goForward();
        } else {
            Toast.makeText(this, "لا يوجد سجل تقدم", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMenu() {
        PopupMenu popup = new PopupMenu(this, btnMenu);
        popup.getMenuInflater().inflate(R.menu.browser_menu, popup.getMenu());

        // تحديث عنوان خيار التصفح الخاص
        MenuItem incognitoItem = popup.getMenu().findItem(R.id.menu_incognito);
        if (incognitoItem != null) {
            if (isIncognitoMode) {
                incognitoItem.setTitle("تعطيل التصفح الخاص");
            } else {
                incognitoItem.setTitle("تفعيل التصفح الخاص");
            }
        }

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					int id = item.getItemId();
					if (id == R.id.menu_new_tab) {
						newTab("https://www.google.com", true);
						return true;
					} else if (id == R.id.menu_close_tab) {
						closeCurrentTab();
						return true;
					} else if (id == R.id.menu_dark_mode) {
						toggleDarkMode();
						return true;
					} else if (id == R.id.menu_ad_block) {
						toggleAdBlock();
						return true;
					} else if (id == R.id.menu_bookmarks) {
						showBookmarks();
						return true;
					} else if (id == R.id.menu_history) {
						showHistory();
						return true;
					} else if (id == R.id.menu_progress) {
						showDownloads();
						return true;
					} else if (id == R.id.menu_forward) {
						goForward();
						return true;
					} else if (id == R.id.menu_home) {
						homeLayout.setVisibility(View.VISIBLE);
						browserLayout.setVisibility(View.GONE);
						return true;
					} else if (id == R.id.menu_incognito) {
						toggleIncognitoMode();
						return true;
					}
					return false;
				}
			});
        popup.show();
    }

    // تفعيل/تعطيل وضع التصفح الخاص
    private void toggleIncognitoMode() {
        isIncognitoMode = !isIncognitoMode;

        // إغلاق جميع التبويبات الحالية
        for(WebView tab : tabs) {
            webviewContainer.removeView(tab);
            tab.destroy();
        }
        tabs.clear();
        currentTabIndex = -1;

        // إنشاء تبويب جديد
        newTab("https://www.google.com", true);

        // تحديث الواجهة
        updateIncognitoUI();

        // إظهار رسالة للمستخدم
        if (isIncognitoMode) {
            Toast.makeText(this, "وضع التصفح الخاص مفعل - لن يتم حفظ أي بيانات", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "وضع التصفح الخاص معطل", Toast.LENGTH_SHORT).show();
        }

        saveStateToPrefs();
    }

    // تحديث الواجهة حسب وضع التصفح الخاص
    private void updateIncognitoUI() {
        if (isIncognitoMode) {
            // تغيير لون الخلفية للوضع الخاص
            browserLayout.setBackgroundColor(Color.parseColor("#303030"));

            // تغيير لون شريط العنوان
            urlBar.setBackgroundColor(Color.parseColor("#424242"));
            urlBar.setTextColor(Color.WHITE);

            // إضافة أيقونة الوضع الخاص
            urlBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_incognito, 0, 0, 0);
        } else {
            // استعادة الألوان الأصلية
            if (isDarkMode) {
                applyDarkMode();
            } else {
                applyLightMode();
            }

            // إزالة أيقونة الوضع الخاص
            urlBar.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        if (v instanceof WebView) {
            WebView webView = (WebView) v;
            HitTestResult result = webView.getHitTestResult();

            if (result.getType() == HitTestResult.SRC_ANCHOR_TYPE) {
                final String url = result.getExtra();
                menu.add(0, 1, 0, "فتح في تبويب جديد").setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
						@Override
						public boolean onMenuItemClick(MenuItem item) {
							newTab(url, true);
							return true;
						}
					});
            }
        }
    }

    private void toggleDarkMode() {
        isDarkMode = !isDarkMode;

        if (isDarkMode) {
            applyDarkMode();
            Toast.makeText(this, "تم تفعيل الوضع الداكن", Toast.LENGTH_SHORT).show();
        } else {
            applyLightMode();
            Toast.makeText(this, "تم تعطيل الوضع الداكن", Toast.LENGTH_SHORT).show();
        }

        saveStateToPrefs();
    }

    private void applyDarkMode() {
        View mainLayout = findViewById(android.R.id.content);
        mainLayout.setBackgroundColor(Color.DKGRAY);
        urlBar.setBackgroundColor(Color.parseColor("#444444"));
        urlBar.setTextColor(Color.WHITE);

        int[] buttonIds = {R.id.btn_forward, R.id.btn_refresh, R.id.btn_menu, 
            R.id.btn_tabs, R.id.btn_home};
        for (int id : buttonIds) {
            Button btn = findViewById(id);
            btn.setBackgroundColor(Color.parseColor("#333333"));
            btn.setTextColor(Color.WHITE);
        }

        for (WebView tab : tabs) {
            tab.setBackgroundColor(Color.BLACK);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WebSettings settings = tab.getSettings();
                settings.setForceDark(WebSettings.FORCE_DARK_ON);
            }
        }
    }

    private void applyLightMode() {
        View mainLayout = findViewById(android.R.id.content);
        mainLayout.setBackgroundColor(Color.WHITE);
        urlBar.setBackgroundColor(Color.WHITE);
        urlBar.setTextColor(Color.BLACK);

        int[] buttonIds = {R.id.btn_forward, R.id.btn_refresh, R.id.btn_menu, 
            R.id.btn_tabs, R.id.btn_home};
        for (int id : buttonIds) {
            Button btn = findViewById(id);
            btn.setBackgroundResource(android.R.drawable.btn_default);
            btn.setTextColor(Color.BLACK);
        }

        for (WebView tab : tabs) {
            tab.setBackgroundColor(Color.WHITE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WebSettings settings = tab.getSettings();
                settings.setForceDark(WebSettings.FORCE_DARK_OFF);
            }
        }
    }

    private void toggleAdBlock() {
        isAdBlockerEnabled = !isAdBlockerEnabled;
        Toast.makeText(this, "حظر الإعلانات " + (isAdBlockerEnabled ? "مفعل" : "معطل"), Toast.LENGTH_SHORT).show();
    }

    private void showBookmarks() {
        final String[] bookmarks = {
            "https://www.google.com",
            "https://www.youtube.com",
            "https://www.facebook.com",
            "https://www.twitter.com"
        };

        PopupMenu bookmarksMenu = new PopupMenu(this, btnMenu);
        for (int i = 0; i < bookmarks.length; i++) {
            bookmarksMenu.getMenu().add(0, i, 0, getDomainName(bookmarks[i]));
        }

        bookmarksMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					int id = item.getItemId();
					if (id >= 0 && id < bookmarks.length) {
						loadUrl(bookmarks[id]);
					}
					return true;
				}
			});

        bookmarksMenu.show();
    }

    private void showHistory() {
        if (isIncognitoMode) {
            Toast.makeText(this, "غير متاح في وضع التصفح الخاص", Toast.LENGTH_SHORT).show();
            return;
        }

        if (history.isEmpty()) {
            Toast.makeText(this, "السجل فارغ", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("السجل (" + history.size() + ")");

        final List<String> finalReversedHistory = new ArrayList<>(history);
        Collections.reverse(finalReversedHistory);

        List<String> displayItems = new ArrayList<>();
        for (String url : finalReversedHistory) {
            String displayText = getReadableHistoryText(url);
            displayItems.add(displayText);
        }

        builder.setItems(displayItems.toArray(new String[0]), new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					String url = finalReversedHistory.get(which);
					loadUrlInCurrentTab(url);
				}
			});

        builder.setNegativeButton("مسح", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					history.clear();
					Toast.makeText(MainActivity.this, "تم مسح السجل", Toast.LENGTH_SHORT).show();
					saveStateToPrefs();
				}
			});

        builder.setPositiveButton("إغلاق", null);
        builder.show();
    }

    private String getReadableHistoryText(String url) {
        if (url == null) {
            return "غير معروف";
        }

        if (url.contains("google.com/search") && url.contains("?q=")) {
            int start = url.indexOf("?q=") + 3;
            int end = url.indexOf('&', start);
            if (end == -1) {
                end = url.length();
            }
            String query = url.substring(start, end);
            query = Uri.decode(query);
            return "بحث: " + query;
        }

        if (url.contains("youtube.com/results") && url.contains("search_query=")) {
            int start = url.indexOf("search_query=") + 13;
            int end = url.indexOf('&', start);
            if (end == -1) {
                end = url.length();
            }
            String query = url.substring(start, end);
            query = Uri.decode(query);
            return "يوتيوب: " + query;
        }

        return getDomainName(url);
    }

    private void showDownloads() {
        if (downloadIds.isEmpty()) {
            Toast.makeText(this, "لا توجد تنزيلات جارية", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("التنزيلات الجارية (" + downloadIds.size() + ")");

        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        List<String> downloadItems = new ArrayList<>();

        for (long id : downloadIds) {
            DownloadManager.Query query = new DownloadManager.Query();
            query.setFilterById(id);
            android.database.Cursor cursor = manager.query(query);

            if (cursor.moveToFirst()) {
                int fileNameIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE);
                int progressIndex = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
                int totalIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);

                String fileName = cursor.getString(fileNameIndex);
                long progress = cursor.getLong(progressIndex);
                long total = cursor.getLong(totalIndex);

                int percent = (total > 0) ? (int) (progress * 100 / total) : 0;
                downloadItems.add(fileName + " - " + percent + "%");
            }
            cursor.close();
        }

        builder.setItems(downloadItems.toArray(new String[0]), null);
        builder.setPositiveButton("موافق", null);
        builder.show();
    }

    private String getDomainName(String url) {
        try {
            Uri uri = Uri.parse(url);
            String domain = uri.getHost();
            if (domain != null && domain.startsWith("www.")) {
                domain = domain.substring(4);
            }
            return domain != null ? domain : url;
        } catch (Exception e) {
            return url;
        }
    }

    private WebView getCurrentWebView() {
        if (currentTabIndex >= 0 && currentTabIndex < tabs.size()) {
            return tabs.get(currentTabIndex);
        }
        return null;
    }

    private void updateUrlBar() {
        WebView current = getCurrentWebView();
        if (current != null) {
            String title = current.getTitle();
            if (title != null && !title.isEmpty()) {
                urlBar.setText(title);
            } else {
                urlBar.setText(current.getUrl());
            }
        }
    }

    private class CustomWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            progressBar.setVisibility(View.VISIBLE);
            urlBar.setText(getDomainName(url));
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            progressBar.setVisibility(View.GONE);
            updateUrlBar();

            // لا تحفظ السجل في وضع التصفح الخاص
            if (url != null && !history.contains(url) && !isIncognitoMode) {
                history.add(url);
                saveStateToPrefs();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    private class CustomWebChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            progressBar.setProgress(newProgress);
            if (newProgress == 100) {
                progressBar.setVisibility(View.GONE);
            } else {
                progressBar.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            if (view == getCurrentWebView()) {
                updateUrlBar();
            }
        }

        // دعم وضع الشاشة الكاملة للفيديو
        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }

            // إخفاء واجهة المتصفح
            browserLayout.setVisibility(View.GONE);

            // إعداد واجهة الفيديو الكاملة
            customView = view;
            customViewCallback = callback;

            FrameLayout decor = (FrameLayout) getWindow().getDecorView();
            decor.addView(customView, new FrameLayout.LayoutParams(
							  ViewGroup.LayoutParams.MATCH_PARENT,
							  ViewGroup.LayoutParams.MATCH_PARENT));
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;

            // إزالة واجهة الفيديو الكاملة
            FrameLayout decor = (FrameLayout) getWindow().getDecorView();
            decor.removeView(customView);

            // استعادة واجهة المتصفح
            browserLayout.setVisibility(View.VISIBLE);

            // تنظيف المتغيرات
            customViewCallback.onCustomViewHidden();
            customView = null;
            customViewCallback = null;
        }
    }
}
